import streamlit as st
from io import BytesIO
import base64
import os
from process_files import start_processing, process_output
import pandas as pd
import time
from tabulate import tabulate 

# === CONFIG ===
UPLOAD_DIR = "uploaded_pdfs"
XL_PATH = 'master_xls/Master data.xlsx'
OUTPUT_PATH = 'out_files'

# Create upload directory if not exists
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Custom styling
# === PAGE SETUP ===
st.set_page_config(
    page_title="Data Verification Tool",
    page_icon="📄",
    layout="centered"
)
st.markdown("""
    <style>
        
        .title {
            text-align: center;
            font-size: 36px;
            color: #4A6EE0;
            margin-bottom: 20px;
        }
        .footer {
            font-size: 12px;
            text-align: center;
            color: gray;
            margin-top: 30px;
        }
        .stButton>button {
        color: white;
        background-color: #4CAF50;
        padding: 10px 24px;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        transition: 0.3s;
    }
     .stButton>button:hover {
        background-color: #45a049;
    }
   
    </style>
""", unsafe_allow_html=True)

st.markdown('<div class="main">', unsafe_allow_html=True)
st.markdown('<div class="title">📄 Data Verification Tool</div>', unsafe_allow_html=True)
# File uploaders
uploaded_pdfs = st.file_uploader("📚 Upload PDF files", type=["pdf"], accept_multiple_files=True)



if st.button("🚀 Start Processing"):
    if uploaded_pdfs:
        try:
            saved_files = []
            timestr = time.strftime("%Y%m%d_%H%M%S")
            for file in uploaded_pdfs:
                file_name = file.name
                file_path = os.path.join(UPLOAD_DIR, file_name)
                
                with open(file_path, "wb") as f:
                    f.write(file.read())
                saved_files.append(file_path)
            st.markdown(f'<div class="status-box"><b>Upload Status:</b> ✅ {len(saved_files)} files saved successfully!</div>', unsafe_allow_html=True)
            # Placeholder for output buttons
            output_btn_placeholder = st.empty()
            res_df = pd.DataFrame() 
            for filepath in saved_files:
                processed_df = start_processing(XL_PATH, filepath) 
                if(len(res_df) == 0):
                    res_df = processed_df
                else:
                    res_df = pd.concat([res_df, processed_df], ignore_index=True)
            
            if (len(res_df) != 0):
                all_df, price_df = process_output(res_df, timestr) 
            
            all_fileName = 'All_Discrepencies_'+timestr+'.xlsx'
            all_file_path = os.path.join(OUTPUT_PATH, all_fileName)
            price_fileName = 'TotalPrice_Discrepancies_'+timestr+'.xlsx'
            price_file_path = os.path.join(OUTPUT_PATH, price_fileName)
            all_markdown_table = tabulate(all_df, headers='keys', tablefmt="grid", showindex=False)
            price_markdown_table = tabulate(price_df, headers='keys', tablefmt="grid", showindex=False)
               
            st.subheader("📄🔎 All Fields Discrepancies:")
            st.code(all_markdown_table, language='text')  
            
            st.subheader("📄💰 Total Price Discrepancies:")
            st.code(price_markdown_table, language='text')
            
            with open(all_file_path, "rb") as all_template_file:
                all_file_path_byte = all_template_file.read()
                
            with open(price_file_path, "rb") as price_template_file:
                price_file_path_byte = price_template_file.read()    
            
            with output_btn_placeholder.container():
                st.download_button(
                    label="📥 Download All Discrepancies",
                    data=all_file_path_byte,
                    file_name=all_fileName,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
                
                st.download_button(
                    label="📥 Download Total Price Discrepancies",
                    data=price_file_path_byte,
                    file_name=price_fileName,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
            
        except Exception as e:
            st.markdown(f'<div class="status-box" style="border-left-color: red;"><b>Error:</b> {str(e)}</div>', unsafe_allow_html=True)    
    else:
        st.markdown('<div class="status-box" style="border-left-color: red;"><b>Upload Status:</b> ❌ No files uploaded!</div>', unsafe_allow_html=True)

# Placeholder for output buttons
output_btn_placeholder = st.empty()        