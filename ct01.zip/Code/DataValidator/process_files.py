import pandas as pd
import read_utils
import convert_utils
from prompt_helper import create_prompt
import open_api_helper
import os

OUTPUT_PATH = 'out_files'

def start_processing(master_xlsx_path, pdf_path):   
    #get the dataframe of master
    master_df = read_utils.read_excel_file(master_xlsx_path)
    #get the dataframe of pdf
    pdf_df = read_utils.read_pdf_file(pdf_path)
    
    # get the common columns
    common_cols = read_utils.get_common_fields(master_df, pdf_df)
    #print(common_cols)
    
    #simplify the dataframe to get only common cols to compare
    master_df = master_df[common_cols]
    pdf_df = pdf_df[common_cols]
    
    # convert to json
    master_df_json = convert_utils.convert_df_to_json(master_df)
    pdf_df_json = convert_utils.convert_df_to_json(pdf_df)
    
    #create prompt
    prompt = create_prompt(master_df_json, pdf_df_json)
    
    #init openai
    client = open_api_helper.init_api()
    output_json = open_api_helper.create_request(prompt, client)
    # the openai is adding meta-info for the output below code to sanitize this
    #cleanup the special chars
    output_json = output_json.strip('` \n')
    #now remove the remaining json string
    if output_json.startswith('json'):
        output_json = output_json[4:]
        
    #convert the json to dataframe
    res_df = convert_utils.convert_json_to_df(output_json)    
    return res_df


def process_output(output_df, suffix):    
    #lets rename and create the two output formats
    fileName = 'All_Discrepencies_'+suffix+'.xlsx'
    file_path = os.path.join(OUTPUT_PATH, fileName)
    df = pd.DataFrame(output_df)
    df = df.rename(columns={'Master Value':'Excel Value', 'Input Value':'PDF Value','Difference':'Discrepancies'})
    df.to_excel(file_path, index=False)
    fileName2 = 'TotalPrice_Discrepancies_'+suffix+'.xlsx'
    file_path2 = os.path.join(OUTPUT_PATH, fileName2)
    tot_price_df = df[df['Field']=='Total']
    tot_price_df = tot_price_df.drop(columns=['Field'])
    tot_price_df = tot_price_df.rename(columns={'Excel Value': 'Total price in master data', 'PDF Value': 'Total price in Invoice', 'Difference':'Discrepancies'}) 
    tot_price_df.to_excel(file_path2, index=False)
    return df, tot_price_df
    
        