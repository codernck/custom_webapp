from json import dumps

def create_prompt(master_json, pdf_json):
    prompt = f"""
    You are given two JSON datasets: input-data and master-data.
    Each contains a list of items with an 'Item' key as reference.
    Compare each item in master-data with the corresponding item in input-data based on 'Item'.
    For all common items:
    - Compare all fields present in both.
    - Do not make assumptions or generate data.
    - Output only differences as a JSON array.
    - Each difference should include:
        - Item: reference item name
        - Field: field where difference is found
        - Master Value: value from master-data
        - Input Value: value from input-data
        - Difference: numerical difference (Master Value - Input Value)

    Here are the datasets:

    Input Data:
    {dumps(pdf_json)}

    Master Data:
    {dumps(master_json)}

    Provide only the JSON array of differences.
    """
    
    return prompt