import os
from process_files import start_processing, process_output
import pandas as pd
import time
from tabulate import tabulate 

# get the paths from user for both the input pdf and the master xlsx file
def user_input(inputType):
    if inputType == 'pdf':
        num_files = int(input("How many input pdf files do you want to process? "))
        if num_files <= 0:
            raise ValueError("Number of files must be a positive integer.")
        
        paths = []
        invalid_paths = []
        for i in range(num_files):
            path = input(f"Enter path for file {i + 1}: ").strip()
            paths.append(path)
            if not os.path.isfile(path):
                invalid_paths.append(path)
        
        if invalid_paths:
            raise FileNotFoundError(f"The following file paths are invalid or do not exist:\n" + "\n".join(invalid_paths))    
        return paths
    
    else:
        xl_path = input(f"Enter path for master xlsx file: ").strip()
        if not os.path.isfile(xl_path):
            raise FileNotFoundError(f"The following file path is invalid or does not exist: {path} \n")
        else:
            return xl_path
        
    


def main():
    try:
        # get the pdf files
        pdf_paths = user_input('pdf')
        xl_path = user_input('xlsx')
        timestr = time.strftime("%Y%m%d_%H%M%S")
        out_filename = 'All_Discrepencies_'+timestr+'.xlsx'
        #pdf_paths = [r'D:\000_ChatGPT_OpenAI_API\Practice\P001\Input data\Input data\Invoice_1.pdf']
        #xl_path = r'D:\000_ChatGPT_OpenAI_API\Practice\P001\Input data\Input data\Master data.xlsx'
        if pdf_paths and xl_path:
            res_df = pd.DataFrame()
            for pdf_path in pdf_paths:
                processed_df = start_processing(xl_path, pdf_path) 
                if(len(res_df) == 0):
                    res_df = processed_df
                else:
                    res_df = pd.concat([res_df, processed_df], ignore_index=True)
                        
            if (len(res_df) != 0):
                all_df, price_df = process_output(res_df, timestr)
            
            all_markdown_table = tabulate(all_df, headers='keys', tablefmt="grid", showindex=False)
            price_markdown_table = tabulate(price_df, headers='keys', tablefmt="grid", showindex=False)
            
            print('---All Fields Differences---')    
            print(all_markdown_table)
            
            print()
            
            print('---Total Price Differences---')    
            print(price_markdown_table)
        
    except Exception as e:
        print(f"Exception: {e}")
    
    
    
    #get the common columns simplify
    
    #convert to json
    
    #send to opeai
    
    #prompt helper
    
    #openai caller
    


if __name__ == "__main__":
    main()    