import pandas as pd
import pdfplumber

def get_common_fields(master_df, pdf_df):
    common_columns = list(set(master_df.columns) & set(pdf_df.columns)) 
    return common_columns

def read_excel_file(path_to_file):
    df = pd.read_excel(path_to_file)
    return df

def read_pdf_file(path_of_pdf):
    #extract the table from pdf
    all_tables = []
    all_dfs = []
    with pdfplumber.open(path_of_pdf) as pdf:
        for page in pdf.pages:
            tbl = page.extract_table()
            all_tables.append(tbl)
    
    for table in all_tables:
        #logic to check from which row the headings start
        #for some file the headings row many not start at 1st row
        header_start_row = -1
        for i, row in enumerate(table):
            if row and any(cell and cell.strip() for cell in row):
                header_start_row=i
                data_rows = table[i+1:]
                break
        pdf_df = pd.DataFrame(data_rows, columns=table[header_start_row])
        all_dfs.append(pdf_df)
        
    if len(all_tables) > 1:
         merged_df = pd.concat(all_dfs, ignore_index=True)
    else:
        merged_df = all_dfs[0]        
        
    return merged_df   
        
          
