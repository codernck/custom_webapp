from dotenv import load_dotenv
import os
from openai import OpenAI

api_key = ''
client = None

def init_api():
    load_dotenv()
    api_key = os.getenv("API_KEY")
    print(f"API Key: {api_key}")
    client = OpenAI(
        api_key=api_key,
    )
    return client
    
def create_request(prompt, client):
    completion = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are an expert data validator.You must compare two json datasets and output only differences in json.Never make assumptions or infer missing data."},
            {
                "role": "user",
                "content": prompt,
            },
        ],
        temperature=0,
    )
    output = completion.choices[0].message.content
    return output    

    