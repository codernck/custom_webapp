from json import loads,dump
import pandas as pd

def convert_df_to_json(pdf_df):
    json_raw = pdf_df.to_json(orient='records')
    json = loads(json_raw)
    return json

def convert_json_to_df(json_string):
    write_to_file(json_string)
    data = loads(json_string)
    df = pd.DataFrame(data)
    return df

#write json for further reference checks
def write_to_file(json_string):
    with open("output.json", "w") as outfile:
        dump(json_string, outfile, indent=4)